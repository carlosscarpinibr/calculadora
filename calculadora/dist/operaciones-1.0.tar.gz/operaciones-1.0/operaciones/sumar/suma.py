def suma(numA,numB):
    '''
        - Descripción:
            Recibe dos numeros reales y los suma.
        - Entrada de datos:
            Dos numeros reales de la función
        - Salida de datos:
            La suma de dos numeros reales
    '''
    suma = numA + numB
    return suma