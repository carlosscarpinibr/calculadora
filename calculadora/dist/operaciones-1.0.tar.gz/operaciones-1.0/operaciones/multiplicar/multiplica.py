def multiplica(numA,numB):
    '''
        - Descripción:
            Recibe dos numeros reales y los multiplica.
        - Entrada de datos:
            Dos numeros reales de la función
        - Salida de datos:
            La multiplicación de dos numeros reales
    '''
    multi = numA * numB
    return multi