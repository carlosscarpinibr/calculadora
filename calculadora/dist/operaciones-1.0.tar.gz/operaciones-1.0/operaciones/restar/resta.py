def resta(numA,numB):
    '''
        - Descripción:
            Recibe dos numeros reales y los resta.
        - Entrada de datos:
            Dos numeros reales de la función
        - Salida de datos:
            La resta de dos numeros reales
    '''
    resta = numA - numB
    return resta